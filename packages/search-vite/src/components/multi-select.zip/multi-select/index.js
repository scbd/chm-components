import Multiselect from './Multiselect.vue';
import multiselectMixin from './multiselectMixin';
import pointerMixin from './pointerMixin';

export default Multiselect;

export { Multiselect, multiselectMixin, pointerMixin };
